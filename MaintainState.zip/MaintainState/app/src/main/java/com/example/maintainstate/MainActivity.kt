package com.example.maintainstate

import android.content.Context
import android.content.SharedPreferences
import android.content.SharedPreferences.Editor
import android.graphics.drawable.Drawable
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.PersistableBundle
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.Toast
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.random.Random

private lateinit var button: Button
private lateinit var editText: EditText
private lateinit var imageView: ImageView
var imageId=0

class MainActivity : AppCompatActivity() {
    lateinit var sharedPreferences: SharedPreferences;
    lateinit var imageList: List<Int>
    lateinit var editor: Editor
    var index=0


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        sharedPreferences  = getSharedPreferences(getString(R.string.PREFERENCE), Context.MODE_PRIVATE)

        imageList = listOf(
            R.drawable.baseline_account_box_24,
            R.drawable.baseline_account_circle_24,
            R.drawable.baseline_add_shopping_cart_24,
            R.drawable.ic_launcher_foreground
            // Add more image resource IDs as needed
        )

        button = findViewById(R.id.button)
        editText = findViewById(R.id.edit_text)
        imageView = findViewById(R.id.image)

        val retriveText = sharedPreferences.getString("Text","")
        imageId = sharedPreferences.getInt("Image",0)

        Log.d("-------+--------", "loaded "+ retriveText+"  "+imageId)

        if(imageId != 0 && !retriveText.equals("")) {
            imageView.setImageResource(imageId)
            editText.setText( retriveText)
        }

        button.setOnClickListener {
            index = Random.nextInt(imageList.size)
            imageId = imageList[index]
            Log.d("-------+--------", "onCreate: "+ imageId)
            imageView.setImageResource(imageId)
        }
    }

    override fun onDestroy() {
            editor = sharedPreferences.edit()
            Log.d("-------+--------", "onDestroy: "+editText.text.toString()+"  "+ imageId)
            editor.putInt("Image",imageId)
            editor.putString("Text", editText.text.toString())
            editor.commit()

        super.onDestroy()
    }
}